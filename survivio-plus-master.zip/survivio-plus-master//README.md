![alt text](https://i.imgur.com/D7k4Jum.jpg "Survivio Banner")

# Welcome to Surviv+! 😃

This is a Surviv.io cheat loaded as a Chrome extension. It was originally developed by [reuke](https://github.com/reuke), but since he has been away, I've decided to take ownership of the development of the code. iBLiSSIN shows the hack in action, check it out [here](https://www.youtube.com/channel/UCLff8YzqQ-vIAFTKPTDz3RA/featured?view_as=subscriber).

If you like this project, and want it to last, please consider supporting. This project lives on borrowed time.

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WZCYV95AA85S4&item_name=Please+help+the+hacks+%3A%29&currency_code=CAD&source=url)

### 💪 Features

* Aimbot with customizable prediction and speed settings
* Custom zooming control with scroll wheel
* Auto Clicker for semi automatic weapons
* Autoloot
* Displays enemy lines
* Transparent buildings, ceilings, obstacles, and trees
* Lasersight (shot range)
* Frag grenade timer
* Custom key bindings
* Custom cursors
* FPS Counter
* Now supports in-game radio!

## 🔨 Installation

1. Download [this repo as a ZIP file](https://github.com/Kalaborative/survivio-cheat/archive/master.zip). 
2. Extract the ZIP file you just downloaded. 
3. Go to `chrome://extensions` in your browser. *Make sure you have Developer Mode activated.*
4. Click "Load Unpacked" and select the folder that you extracted (called `survivio-cheat-master`)
5. Open [surviv.io](http://surviv.io).

## 🤔 FAQ
> **The game freezes frequently, how to fix?**

Fix for freezing: https://www.youtube.com/watch?v=29Ws50lRm04

> **'Unauthorized extension use detected', how to fix?**

Fix: https://www.youtube.com/watch?v=pEEa6b3oXjA

> **"Please update extension for best results!" What does this mean??!!! WTF**

Official Download / Update Guide: https://www.youtube.com/watch?v=xRoCoMei3Nc

Calm down jeez. The hack was updated and therefore you need to update. Go to chrome://extensions/ and click remove on the survivio+ extension. Download the new version and load that one as the hack. There you go. No issues about this please.
> **What do I do if the cheat stops working?**

Message silentes#4242 on discord if the game is updated.

> **This feature isn't working for me! WTF?**

Relax. Open the console (Hit F12), and copy what the error is, and just [create an issue](https://github.com/Kalaborative/survivio-cheat/issues). Do not open an issue if you already see the same one. If you do, you will be banned from using the cheat.

> **What is "bump fire"?**

This is a feature for specific non-automatic guns (guns that you cannot hold down the left-click to shoot). By holding down left-click for these guns, they fire at the fastest rate acting like an automatic. (Think of it like an autoclicker.)

> **Why isn't this on the Chrome Web Store?**

This was on the store before, but it got taken down (not sure why). I could try uploading it myself, but this will be the safest route for now.

> **Are pull requests allowed?**

Your contributions are always welcome. If you see something that should be improved or a feature added, feel free to fork this repo and create a PR. 

> **Is the Hack working?**

Check👏for👏yourselves👏you👏lazy👏fucks👏
